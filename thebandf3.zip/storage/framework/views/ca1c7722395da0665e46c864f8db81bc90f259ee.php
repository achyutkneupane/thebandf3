<div class="container my-4" id="profile">
    <div class="shadowbox">
        <div class="row justify-content-center">
            <div class="col-md-12 text-center">
                <h1 class="Title">
                    About F3
                </h1>
                <div class="vLine"></div>
            </div>
            <div class="col-md-9">
                <div class="profileText">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse nulla elit, vestibulum quis posuere a, aliquam at nulla. In faucibus ullamcorper dui, nec consectetur sapien dapibus quis. Pellentesque vel egestas orci. Sed a semper diam. Maecenas pulvinar dui euismod erat imperdiet, eleifend semper mauris posuere. Nunc fringilla tincidunt laoreet. Aenean vel interdum arcu. In fringilla tortor tortor, vitae condimentum metus tempus non. Aenean et faucibus quam. Fusce varius blandit aliquam. Morbi orci diam, gravida sed dapibus nec, vehicula a justo. Sed maximus eget sem sit amet ultricies. Phasellus sed tempus elit. Donec at dictum elit, vel consectetur neque.
                    Etiam eget mollis felis. Suspendisse in eros scelerisque, ullamcorper elit non, viverra turpis. Maecenas placerat neque quis commodo fermentum. Maecenas iaculis enim id dignissim eleifend. Aliquam vestibulum elit eget mi fermentum, vel malesuada quam varius. Aenean varius, erat at sollicitudin feugiat, lectus arcu lacinia quam, eu ultrices purus lectus ut dolor. Suspendisse faucibus iaculis mi, sed ultrices tortor dignissim blandit. Fusce sed sapien augue. Sed molestie aliquet libero, eu tincidunt ex ornare ac. Suspendisse pulvinar at eros in posuere. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Integer fringilla volutpat sem id fringilla. Maecenas condimentum convallis mauris non posuere.
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\nec\htdocs\f3band\resources\views/page/profile.blade.php ENDPATH**/ ?>