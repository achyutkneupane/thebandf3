<div class="bannerImage bgImage" style="background-image: url('<?php echo e(asset('statics/thebandf3.jpg')); ?>');">
    <div class="transImage"></div>
    <div class="bannerSection container text-center">
        <div class="row">
            <div class="col-md-12">
                <h1 class="bannerTitle">The Band F3</h1>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\nec\htdocs\f3band\resources\views/banner.blade.php ENDPATH**/ ?>