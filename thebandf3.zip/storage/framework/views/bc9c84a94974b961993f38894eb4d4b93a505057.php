F3
<?php /**PATH C:\xampp\nec\htdocs\f3band\resources\views/head.blade.php ENDPATH**/ ?>